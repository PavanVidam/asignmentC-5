﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Asgmnt5
{
    class ValidationNames : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string clientName = value.ToString();
            string[] splitClientName = clientName.Split(' ');
            int WrongCount = 0;
            if (clientName.Length == 0)
            {
                WrongCount++;
            }
            else
            {
                for (int i = 0; i < splitClientName.Length; i++)
                {
                    char[] clientNameArrayChar = splitClientName[i].ToCharArray();
                    for (int j = 0; j < clientNameArrayChar.Length; j++)
                    {
                        if (!char.IsLetter(clientNameArrayChar[j]))
                        {
                            WrongCount++;
                        }
                    }
                }
            }
            if (WrongCount > 0)
            {
                return new ValidationResult(false, "Enter the valid value!");
            }
            return ValidationResult.ValidResult;
        }
    }
}
