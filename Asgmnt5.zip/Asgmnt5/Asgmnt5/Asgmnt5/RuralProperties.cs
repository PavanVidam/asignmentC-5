﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asgmnt5
{
    public class RuralProperties : Clients
    {
        private bool isCheckSandInWater;

        public bool IsCheckSandInWater { get => isCheckSandInWater; set => isCheckSandInWater = value; }

        public RuralProperties() { }

        public RuralProperties(string name, decimal sizeOfTheProperty, string sizeOfTheHoldingTank, string creditCard, bool isCheckSandInWater) : base(name, sizeOfTheProperty, sizeOfTheHoldingTank, creditCard)
        {
            this.isCheckSandInWater = isCheckSandInWater;
        }

        public override void Requirement()
        {
            Console.WriteLine("Appointment Slot Booked");
        }
        public override string ToString()
        {
            return string.Format($"The Total Size Of Property{SizeOfTheProperty} sqmtrs for {ClientName} , the size of Holding Tank is {SizeOfTheHoldingTank} gallons, " +
                $"credit Card number is {CreditCard} and sand in water {(isCheckSandInWater ? "is Checked" : "is not Checked")}");
        }
    }
}
