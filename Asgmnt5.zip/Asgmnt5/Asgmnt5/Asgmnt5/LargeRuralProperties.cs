﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asgmnt5
{
    public class LargeRuralProperties : Clients
    {
        private bool isCheckThePumpSunken;

        public bool IsCheckThePumpSunken { get => isCheckThePumpSunken; set => isCheckThePumpSunken = value; }

        public LargeRuralProperties() { }

        public LargeRuralProperties(string name, decimal sizeOfTheProperty, string sizeOfTheHoldingTank, string creditCard, bool isCheckSandInWater) : base(name, sizeOfTheProperty, sizeOfTheHoldingTank, creditCard)
        {
            this.IsCheckThePumpSunken = isCheckThePumpSunken;
        }

        public override void Requirement()
        {
            Console.WriteLine("Appointment Slot Booked");
        }

        public override string ToString()
        {
            return string.Format($"The Total Size Of Property{SizeOfTheProperty} sqmtrs for {ClientName} , the size of Holding Tank is {SizeOfTheHoldingTank} gallons, " +
                $"credit Card number is {CreditCard} and The pump sunken in the well {(isCheckThePumpSunken ? "is Checked" : "is not Checked")}");
        }


    }
}
