﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asgmnt5
{
    public class CityHouses : Clients
    {
        private bool isCheckConnection;
        public bool IsCheckConnection { get => isCheckConnection; set => isCheckConnection = value; }
        public CityHouses() { }
        public CityHouses(string name, decimal sizeOfTheProperty, string sizeOfTheHoldingTank, string creditCard, bool isCheckConnection) : base(name, sizeOfTheProperty, sizeOfTheHoldingTank, creditCard)
        {
            this.isCheckConnection = isCheckConnection;
        }
        public override void Requirement()
        {
            Console.WriteLine("Appointment Slot Booked");
        }
        public override string ToString()
        {
            return string.Format($"The Total Size Of Property{SizeOfTheProperty} sqmtrs for {ClientName} , the size of Holding Tank is {SizeOfTheHoldingTank} gallons, " +
                $"credit Card number is {CreditCard} and The Connection of house {(isCheckConnection ? "is Checked" : "is not Checked")}");
        }
    }
}
