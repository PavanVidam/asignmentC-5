﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Asgmnt5
{
    [XmlRoot("AppointmentsList")]
    public class AppointmentsList : IEnumerable
    {
        [XmlArray("AppointmentsArray")]
        [XmlArrayItem("Appointments", typeof(Appointments))]
        private List<Appointments> listAppntObj = null;
        public List<Appointments> ScheduleListObj { get => listAppntObj; set => listAppntObj = value; }

        public AppointmentsList()
        {
            listAppntObj = new List<Appointments>();
        }

        public Appointments this[int i]
        {
            get => this.listAppntObj[i]; set => this.listAppntObj[i] = value;
        }
        public IEnumerator<Appointments> GetEnumerator()
        {
            return ((IEnumerable<Appointments>)listAppntObj).GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<Appointments>)listAppntObj).GetEnumerator();
        }
        public int Count
        {
            get => this.listAppntObj.Count;
        }
        public void Add(Appointments appntObj)
        {
            listAppntObj.Add(appntObj);
        }

        public void RemoveFromList(Appointments appntObj)
        {
            listAppntObj.Remove(appntObj);
        }


        public void ClearList()
        {
            listAppntObj.Clear();
        }
        public void Sort()
        {
            listAppntObj.Sort();
        }

    }
}
