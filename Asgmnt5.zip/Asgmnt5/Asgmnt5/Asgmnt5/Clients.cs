﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Asgmnt5
{
    [XmlInclude(typeof(CityHouses))]
    [XmlInclude(typeof(RuralProperties))]
    [XmlInclude(typeof(LargeRuralProperties))]
    public abstract class Clients : IClient
    {
        private string clientName;
        private decimal sizeOfTheProperty;
        private string sizeOfTheHoldingTank;
        private string creditCard;

        public string ClientName { get => clientName; set => clientName = value; }
        public decimal SizeOfTheProperty { get => sizeOfTheProperty; set => sizeOfTheProperty = value; }
        public string SizeOfTheHoldingTank { get => sizeOfTheHoldingTank; set => sizeOfTheHoldingTank = value; }
        public string CreditCard { get => creditCard; set => creditCard = value; }


        public string MaskCreditCardNum { get => MaskCreditCardNumber(); }

        public string MaskCreditCardNumber()
        {
            bool isCcValid = ValidCreditCardNumber();
            if (!isCcValid)
            {
                return null;
            }
            char[] ccNumArr = CreditCard.ToCharArray();
            for (int i = 5; i < 14; i++)
            {
                if (ccNumArr[i] != ' ')
                {
                    ccNumArr[i] = 'X';
                }
            }
            return new string(ccNumArr);
        }

        public abstract void Requirement();

        public Clients() { }
        public Clients(string clientName, decimal sizeOfTheProperty, string sizeOfTheHoldingTank, string creditCard)
        {
            this.ClientName = clientName;
            this.SizeOfTheHoldingTank = sizeOfTheHoldingTank;
            this.SizeOfTheProperty = sizeOfTheProperty;
            this.CreditCard = creditCard;
        }

        public void CheckPipes()
        {
            Console.Write("check the pipes");
        }

        public void ThightenConnections()
        {
            Console.Write("Thighten the connections");
        }

        public void ApplyPipeInsulation()
        {
            Console.Write("Apply insulation to the property");
        }

        public bool ValidateClientName()
        {
            string[] splitClientName = ClientName.Split(' ');
            int wrongCount = 0;
            if (ClientName.Length == 0)
            {
                wrongCount++;
            }
            else
            {
                for (int i = 0; i < splitClientName.Length; i++)
                {
                    char[] clientNameArrChar = splitClientName[i].ToCharArray();
                    for (int j = 0; j < clientNameArrChar.Length; j++)
                    {
                        if (!char.IsLetter(clientNameArrChar[j]))
                        {
                            wrongCount++;
                        }
                    }
                }
            }
            return (wrongCount > 0 ? false : true);
        }

        public bool ValidateSizeOfTheProperty()
        {
            bool isSizeOfPropertyValid = false;
            if ((SizeOfTheProperty >= 1500) || (SizeOfTheProperty <= 30))

            {
                isSizeOfPropertyValid = false;
            }
            else
            {
                isSizeOfPropertyValid = true;
            }
            return isSizeOfPropertyValid;
        }

        public bool ValidateSizeOfTheHoldingTank()
        {
            bool isSizeOfHoldingTankValid = false;
            decimal sizeOfHoldingTank = 0;
            if ((!decimal.TryParse(sizeOfTheHoldingTank, out sizeOfHoldingTank)) || (sizeOfHoldingTank <= 0) || !(sizeOfHoldingTank < 100))
            {
                isSizeOfHoldingTankValid = false;
            }
            else
            {
                isSizeOfHoldingTankValid = true;
            }
            return isSizeOfHoldingTankValid;
        }

        public bool ValidCreditCardNumber()
        {
            bool isCreditCardNumberValid = false;

            if ((CreditCard != null) && (CreditCard.Length == 19))
            {
                string[] CCNumArr = CreditCard.Split(' ');
                char[] CCNumChar = CreditCard.ToCharArray();
                if (CCNumArr.Length == 4)
                {
                    for (int i = 0; i < CCNumChar.Length; i++)
                    {
                        if (char.IsDigit(CCNumChar[i]) || (CCNumChar[i] == ' '))
                        {
                            isCreditCardNumberValid = true;
                        }
                        else
                        {
                            isCreditCardNumberValid = false;
                            break;
                        }
                    }
                }

            }

            return isCreditCardNumberValid;
        }
             
    }
}