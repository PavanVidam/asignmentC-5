﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asgmnt5
{
    public class Appointments
    {
        private string timeSlot;
        private Clients clients;

        public string TimeSlot { get => timeSlot; set => timeSlot = value; }
        public Clients Clients { get => clients; set => clients = value; }
    }
}
