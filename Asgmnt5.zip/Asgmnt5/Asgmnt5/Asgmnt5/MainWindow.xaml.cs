﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;

namespace Asgmnt5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Boolean[] errFlag = new Boolean[6] { true, true, true, true, true, true };
        AppointmentsList appListObj = new AppointmentsList();
        AppointmentsList xmlListObj = new AppointmentsList();
        Appointments[] appntFinalArray = new Appointments[10];
        ArrayList arrayListObj = new ArrayList();
      
        string xmlFilePath = "appointments.xml";

        public ObservableCollection<ScheduleMeet> ScheduleList { get; set; } = null;
        public ScheduleMeet ScheduleMeet { get; set; }
        IClient client = new CityHouses();
        string addInfo = string.Empty;

        enum Properties
        {
            CityHouses,
            RuralProperties,
            LargeRuralProperties
        }

        public MainWindow()
        {
            InitializeComponent();
            FetchTypeOfProperty();
            FetchAppointments();
            ScheduleList = new ObservableCollection<ScheduleMeet>();
            DataContext = this;
            cbxAppointment.SelectedIndex = 0;
            cbxTypeOfProperty.SelectedIndex = 0;
        }

        public void RemoveTimeSlot()
        {
            cbxAppointment.ItemsSource = null;
            xmlListObj.ClearList();
            GetXmlData();
            foreach (var appointments in xmlListObj)
            {
                appListObj.Add(appointments);
                arrayListObj.Remove(appointments.TimeSlot);
            }
            cbxAppointment.ItemsSource = arrayListObj;
            cbxAppointment.SelectedIndex = 0;
        }

        private void GetXmlData()
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(AppointmentsList));
            if (File.Exists(xmlFilePath))
            {
                TextReader treader = new StreamReader(xmlFilePath);
                xmlListObj = (AppointmentsList)xmlSerializer.Deserialize(treader);
                treader.Close();
            }

        }

        public void FetchAppointments()
        {
            string[] appntArray = new string[10] { "09:00", "10:00", "11:00", "12:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00" };
            for (int i = 0; i < appntArray.Length; i++)
            {
                appntFinalArray[i] = new Appointments();
                appntFinalArray[i].TimeSlot = appntArray[i];
                arrayListObj.Add(appntArray[i]);
            }
            RemoveTimeSlot();
        }

        public void FetchTypeOfProperty()
        {
            var EnumProperties = Enum.GetValues(typeof(Properties));

            foreach (var Property in EnumProperties)
            {
                cbxTypeOfProperty.Items.Add(Property);
            }
        }

        public void SetNameTextBox()
        {
            client.ClientName = tbxClientName.Text;
            if (client.ValidateClientName())
            {
                tbxClientName.Foreground = Brushes.Black;
                tbxClientName.BorderBrush = new SolidColorBrush(Colors.Black);
                lblNameErr.Content = "";
                errFlag[0] = false;
            }
            else
            {
                tbxClientName.BorderBrush = new SolidColorBrush(Colors.Red);
                tbxClientName.Foreground = Brushes.Red;
                lblNameErr.Content = "enter the valid values";
                errFlag[0] = true;
            }

        }

        public void SetSizeOfPropertyTextBox()
        {
            string sizeOfPropertyString = tbxSizeOfTheProperty.Text;
            decimal sizeOfPropertyDecimal = 0;
            decimal.TryParse(sizeOfPropertyString, out sizeOfPropertyDecimal);
            client.SizeOfTheProperty = sizeOfPropertyDecimal;
            if (client.ValidateSizeOfTheProperty())
            {
                tbxSizeOfTheProperty.Foreground = Brushes.Black;
                tbxSizeOfTheProperty.BorderBrush = new SolidColorBrush(Colors.Black);
                errFlag[1] = false;
                lblSizeOfTheProperty.Content = "";
            }
            else
            {
                lblSizeOfTheProperty.Content = "enter values upto 1500";
                tbxSizeOfTheProperty.BorderBrush = new SolidColorBrush(Colors.Red);
                tbxSizeOfTheProperty.Foreground = Brushes.Red;
                errFlag[1] = true;
            }

        }

        public void SetSizeOfTheHoldingTankTextBox()
        {
            client.SizeOfTheHoldingTank = tbxSizeOfHoldingTank.Text;
            if (client.ValidateSizeOfTheHoldingTank())
            {
                tbxSizeOfHoldingTank.Foreground = Brushes.Black;
                tbxSizeOfHoldingTank.BorderBrush = new SolidColorBrush(Colors.Black);
                errFlag[2] = false;
                lblSizeOfHoldingTank.Content = "";
            }
            else
            {
                lblSizeOfHoldingTank.Content = "number less than 100";
                tbxSizeOfHoldingTank.BorderBrush = new SolidColorBrush(Colors.Red);
                tbxSizeOfHoldingTank.Foreground = Brushes.Red;
                errFlag[2] = true;
            }
        }

        public void SetCreditCardTextBox()
        {
            client.CreditCard = tbxCreditCard.Text;
            if (client.ValidCreditCardNumber())
            {
                tbxCreditCard.Foreground = Brushes.Black;
                tbxCreditCard.BorderBrush = new SolidColorBrush(Colors.Black);
                errFlag[3] = false;
                lblCreditCard.Content = "";
            }
            else
            {
                lblCreditCard.Content = "enter valid credit card number";
                tbxCreditCard.BorderBrush = new SolidColorBrush(Colors.Red);
                tbxCreditCard.Foreground = Brushes.Red;
                errFlag[3] = true;
            }
        }


        public void SetAdditionalInfo(RadioButton rb)
        {
            if ((rb.Name != "yes") && (rb.Name != "no"))
            {
                errFlag[4] = true;
            }
            else
            {
                errFlag[4] = false;
                addInfo = rb.Name;
            }
        }

        public void BookAppointmentTime()
        {
            SetCreditCardTextBox();
            SetNameTextBox();
            SetSizeOfPropertyTextBox();
            SetSizeOfTheHoldingTankTextBox();
            if (errFlag[0] == true || errFlag[1] == true || errFlag[2] == true || errFlag[3] == true)
            {
                lblBookAppmnt.Foreground = Brushes.Red;
                lblBookAppmnt.Content = "Appointment is not scheduled. Enter all the fields!.";
            }
            else
            {
                int index = cbxAppointment.SelectedIndex;
                if (index == -1)
                {
                    MessageBox.Show("Appointments are scheduled");
                }
                else
                {
                    appntFinalArray[index].Clients = MakeNewAppointment();
                    appntFinalArray[index].TimeSlot = cbxAppointment.Text;
                    appListObj.Add(appntFinalArray[index]);
                    WriteXmlData(appListObj);
                    appListObj.ClearList();
                    RemoveTimeSlot();
                    lblBookAppmnt.Foreground = Brushes.Black;
                    lblBookAppmnt.Content = "Appointment is scheduled!.";
                }
            }
        }

        public Clients MakeNewAppointment()
        {
            Clients clients = null;
            string CCNumMaskString = client.MaskCreditCardNum;

            switch (cbxTypeOfProperty.SelectedValue)
            {
                case Properties.RuralProperties:
                    clients = new RuralProperties(client.ClientName, client.SizeOfTheProperty, client.SizeOfTheHoldingTank, CCNumMaskString, (addInfo.ToUpper() == "YES") ? true : false);
                    break;
                case Properties.CityHouses:
                    clients = new CityHouses(client.ClientName, client.SizeOfTheProperty, client.SizeOfTheHoldingTank, CCNumMaskString, (addInfo.ToUpper() == "YES") ? true : false);
                    break;
                case Properties.LargeRuralProperties:
                    clients = new LargeRuralProperties(client.ClientName, client.SizeOfTheProperty, client.SizeOfTheHoldingTank, CCNumMaskString, (addInfo.ToUpper() == "YES") ? true : false);
                    break;
                default:
                    Console.WriteLine("choose the service you are looking for");
                    break;
            }
            return clients;
        }

        public void DisplayList()
        {
            xmlListObj.ClearList();
            ScheduleList.Clear();
            GetXmlData();

            foreach (var xmlData in xmlListObj)
            {
                ScheduleMeet scheObj = new ScheduleMeet();
                scheObj.TimeSlot = xmlData.TimeSlot;
                scheObj.ClientName = xmlData.Clients.ClientName;
                scheObj.Property = (int)xmlData.Clients.SizeOfTheProperty;
                scheObj.HoldingTank = xmlData.Clients.SizeOfTheHoldingTank;
                scheObj.CreditCardNumber = xmlData.Clients.CreditCard;
                scheObj.ExtraInformation = "Extra Information";
                ScheduleList.Add(scheObj);
            }
            ScheduleMeet scheObject = new ScheduleMeet();

            dgrdAppointmentList.ItemsSource = null;
            dgrdAppointmentList.ItemsSource = ScheduleList;
        }

        private void NameTextBox(object sender, TextChangedEventArgs e)
        {
            SetNameTextBox();
        }

        private void SizeOfPropertyTextBox(object sender, TextChangedEventArgs e)
        {
            SetSizeOfPropertyTextBox();
        }
        private void SizeOfTheHoldingTankTextBox(object sender, TextChangedEventArgs e)
        {
            SetSizeOfTheHoldingTankTextBox();
        }
        private void CreditCardTextBox(object sender, TextChangedEventArgs e)
        {
            SetCreditCardTextBox();
        }

        private void WriteXmlData(AppointmentsList appListObj)
        {
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(AppointmentsList));
                TextWriter twriter = new StreamWriter(xmlFilePath);
                xmlSerializer.Serialize(twriter, appListObj);
                twriter.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        private void AdditionalInfo(object sender, RoutedEventArgs e)
        {
            RadioButton rbtn = (RadioButton)sender;
            SetAdditionalInfo(rbtn);
        }

        private void OnClickScheduleAppointment(object sender, RoutedEventArgs e)
        {
            BookAppointmentTime();
        }
        private void OnClickDisplayList(object sender, RoutedEventArgs e)
        {
            dgrdAppointmentList.ItemsSource = null;
            DisplayList();

        }
        private void OnClickSearch(object sender, RoutedEventArgs e)
        {
            if (tbxSearch.Text == null)
            {
                dgrdAppointmentList.ItemsSource = ScheduleList;
            }
            else
            {
                var queryResult = from Schedule in ScheduleList
                                  where Schedule.ClientName == tbxSearch.Text
                                  select Schedule;
                dgrdAppointmentList.ItemsSource = queryResult;
            }
        }
    }
}
