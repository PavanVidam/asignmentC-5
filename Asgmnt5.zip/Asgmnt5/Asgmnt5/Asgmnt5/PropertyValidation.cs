﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Globalization;

namespace Asgmnt5
{
    class PropertyValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            decimal PropertyDecimal = 0;
            string PropertyString = value.ToString();
            decimal.TryParse(PropertyString, out PropertyDecimal);
            if ((PropertyDecimal >= 100) || (PropertyDecimal <= 0))

            {
                return new ValidationResult(false, "Enter Values upto 1500");

            }
            return ValidationResult.ValidResult;
            throw new NotImplementedException();
        }
    }
}
