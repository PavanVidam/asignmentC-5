﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Controls;

namespace Asgmnt5
{
    class CreditCardValidation : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            bool isCreditCardValid = false;

            string CreditCardNum = value.ToString();

            if ((CreditCardNum != null) && (CreditCardNum.Length == 19))
            {
                string[] CCNumArray = CreditCardNum.Split(' ');
                char[] CCNumChar = CreditCardNum.ToCharArray();
                if (CCNumArray.Length == 4)
                {
                    for (int i = 0; i < CCNumChar.Length; i++)
                    {
                        if (char.IsDigit(CCNumChar[i]) || (CCNumChar[i] == ' '))
                        {
                            isCreditCardValid = true;
                        }
                        else
                        {
                            isCreditCardValid = false;
                            break;
                        }
                    }
                }

            }

            if (!isCreditCardValid)
            {
                return new ValidationResult(false, "The Format Of CreditCard is XXXX XXXX XXXX XXXX");
            }

            return ValidationResult.ValidResult;
        }
    }
}
