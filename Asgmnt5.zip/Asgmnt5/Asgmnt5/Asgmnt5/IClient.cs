﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asgmnt5
{
    public interface IClient
    {
        string ClientName { get; set; }
        decimal SizeOfTheProperty { get; set; }
        string SizeOfTheHoldingTank { get; set; }
        string CreditCard { get; set; }
        string MaskCreditCardNum { get; }

        bool ValidateClientName();
        bool ValidateSizeOfTheProperty();
        bool ValidateSizeOfTheHoldingTank();
        bool ValidCreditCardNumber();
        string MaskCreditCardNumber();
        void CheckPipes();
        void ThightenConnections();
        void ApplyPipeInsulation();
    }
}
